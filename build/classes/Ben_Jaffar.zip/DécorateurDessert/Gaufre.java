/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DécorateurDessert;

/**
 *
 * @author franck
 */
public class Gaufre extends Dessert {
    public Gaufre() {
        setNom("Une gaufre");
        setPrix(1.80);
    }
}
